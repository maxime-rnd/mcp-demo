# MCP publication lab

This directory is intentionally separate from the MCP server itself.

The lab is a **real MCP client**: it starts `credit_mcp.server` over stdio,
initializes an MCP session, discovers the published tools with `list_tools`, and
executes the test cases with `call_tool`.

It never imports `db.py` or calls business functions directly. This makes the
lab useful for checking the MCP contract rather than merely unit-testing Python.

## Commands

```bash
uv run credit-mcp-lab list
uv run credit-mcp-lab run
uv run credit-mcp-lab run --only positive-simuler-auto
```

The full run validates the publication fixture contains exactly **5 positive +
3 negative** cases, as required by the publication checklist.

## Scope

The local protocol runner validates the deterministic server contract and the
negative/error behavior. It is deliberately separate from model evaluation.
For Claude/ChatGPT or an OpenAI-compatible model, use the same `fixtures/cases.json`
and evaluate the observed tool calls against this lab's evaluator.
