# Credit MCP Demo

Production-oriented MCP demo for a fictional credit assistant.

## Project structure

```text
.
├── pyproject.toml
├── src/credit_mcp/
│   ├── auth.py        # OAuth 2.1 resource-server JWT/JWKS validation
│   ├── config.py      # environment configuration
│   ├── db.py          # fake data access layer
│   ├── logging.py     # JSONL audit log with redaction
│   └── server.py      # MCP tools/resources/prompts
├── fixtures/cases.json # exactly 5 positive + 3 negative publication cases
└── tests/
```

## Local development

```bash
uv sync
uv run pytest
uv run python -m credit_mcp.server
```

The default local mode uses stdio and `CREDIT_MCP_DEMO_CLIENT_ID=CLI-001`.
This fallback exists only for local development. A public deployment must enable OAuth.

## Production OAuth

The MCP server is an OAuth 2.1 **resource server**. It does not issue tokens.
Configure an external IdP (Entra ID, Okta, Keycloak, Auth0, etc.) and set:

```env
CREDIT_MCP_OAUTH_ISSUER_URL=https://idp.example.com/
CREDIT_MCP_OAUTH_RESOURCE_SERVER_URL=https://credit.example.com/mcp
CREDIT_MCP_OAUTH_JWKS_URL=https://idp.example.com/.well-known/jwks.json
CREDIT_MCP_OAUTH_AUDIENCE=https://credit.example.com/mcp
CREDIT_MCP_OAUTH_REQUIRED_SCOPES=["credit:read"]
CREDIT_MCP_HOST=0.0.0.0
CREDIT_MCP_PORT=8000
CREDIT_MCP_ALLOWED_HOSTS=["credit.example.com:443"]
```

Then:

```bash
uv run python -m credit_mcp.server
```

With OAuth configured, Streamable HTTP is exposed at `/mcp` and the SDK publishes
the RFC 9728 protected-resource metadata endpoint. The authorization-server metadata
(`/.well-known/oauth-authorization-server`) is provided by the IdP, not by this
resource server.

### Identity isolation

Tools never accept a client/user ID as an argument. The identity comes from the
validated access token. Therefore `statut_demande` and `lister_demandes` can only
access data belonging to the authenticated principal.

### Security checklist

- HTTPS at the public ingress/load balancer.
- External IdP with OAuth 2.1 / Authorization Code + PKCE where applicable.
- Register Claude and OpenAI callback URLs in the IdP/client registration.
- Use least-privilege scopes.
- Keep secrets out of source control.
- Keep `calls.jsonl` free of bearer tokens and personal data.
- Configure rate limiting and monitoring at the ingress.
- Keep the tool surface stable after submission.
- Run MCP Inspector against the production endpoint before submission.

## Publication test cases

`fixtures/cases.json` intentionally contains exactly the eight review cases:
**5 positive + 3 negative**.

The three negative cases verify that the model does not:
1. create a request when the user only asks for a simulation;
2. bypass amount validation;
3. access another client's request.

## Important limitation

The code implements the **resource-server half** of OAuth: token verification,
scope enforcement and identity propagation. It does not pretend to implement an
identity provider. For production, the IdP must expose authorization-server
metadata and issue access tokens for this resource.

## MCP publication lab

The publication cases are executed by a **separate MCP client** under `credit_mcp_lab`.
The lab starts the server over MCP stdio, initializes a `ClientSession`, discovers tools
with `list_tools`, and invokes them with `call_tool`. It does not import the fake DB or
call the server's Python functions directly.

```bash
uv run credit-mcp-lab list
uv run credit-mcp-lab run
uv run credit-mcp-lab run --only negative-cross-client
```

The full suite checks that `fixtures/cases.json` contains exactly 5 positive and 3 negative
publication cases. The lab is deliberately separate from the production MCP server so that
server unit tests and MCP integration/publication tests remain distinct.
