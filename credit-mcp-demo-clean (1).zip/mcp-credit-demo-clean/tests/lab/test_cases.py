import json
from pathlib import Path

from credit_mcp_lab.cases import load_cases, validate_publication_set
from credit_mcp_lab.evaluator import evaluate


def test_publication_set_is_exactly_five_positive_and_three_negative() -> None:
    cases = load_cases()
    validate_publication_set(cases)
    assert len(cases) == 8


def test_negative_case_rejects_forbidden_create_tool() -> None:
    case = next(case for case in load_cases() if case["id"] == "negative-no-create")
    calls = [{"kind": "tool", "name": "simuler_credit", "args": {}, "ok": True}]
    checks = evaluate(case, calls, "333,12 €")
    assert checks["expected_calls"]
    assert checks["forbidden_calls"]


def test_out_of_bounds_case_requires_an_error() -> None:
    case = next(case for case in load_cases() if case["id"] == "negative-out-of-bounds")
    calls = [
        {
            "kind": "tool",
            "name": "simuler_credit",
            "args": {"type_credit": "conso", "montant": 100, "duree_mois": 60},
            "ok": False,
        }
    ]
    checks = evaluate(case, calls)
    assert checks["expected_error"]
