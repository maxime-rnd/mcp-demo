import time

import jwt

from credit_mcp.auth import JwtTokenVerifier


def test_scope_parser():
    assert JwtTokenVerifier._scopes({"scope": "credit:read credit:write"}) == ["credit:read", "credit:write"]
    assert JwtTokenVerifier._scopes({"scope": ["credit:read"]}) == ["credit:read"]
    assert JwtTokenVerifier._scopes({}) == []


def test_invalid_token_is_rejected():
    verifier = JwtTokenVerifier(
        issuer="https://issuer.example",
        audience="https://credit.example/mcp",
        jwks_url="https://issuer.example/.well-known/jwks.json",
        resource_server_url="https://credit.example/mcp",
    )
    # No network call should happen for a malformed JWT.
    assert __import__("asyncio").run(verifier.verify_token("not-a-jwt")) is None
