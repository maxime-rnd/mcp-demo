from credit_mcp.config import Settings
from credit_mcp.server import build_server


def test_tool_surface_is_stable():
    mcp = build_server(Settings())
    names = {tool.name for tool in mcp._tool_manager.list_tools()}
    assert names == {
        "simuler_credit",
        "consulter_capacite_emprunt",
        "preparer_demande_credit",
        "statut_demande",
        "lister_demandes",
    }


def test_publication_cases_have_exactly_five_positive_and_three_negative():
    import json
    from pathlib import Path

    cases = json.loads((Path(__file__).parents[1] / "fixtures" / "cases.json").read_text())
    assert len(cases) == 8
    assert sum(case["type"] == "positive" for case in cases) == 5
    assert sum(case["type"] == "negative" for case in cases) == 3
