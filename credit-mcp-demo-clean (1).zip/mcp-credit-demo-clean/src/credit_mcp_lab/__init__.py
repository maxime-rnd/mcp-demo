"""Publication and MCP integration test lab for the credit demo."""
