"""Load and validate publication test cases."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

CASES_PATH = Path(__file__).resolve().parents[2] / "fixtures" / "cases.json"


def load_cases(only: str | None = None) -> list[dict[str, Any]]:
    cases = json.loads(CASES_PATH.read_text(encoding="utf-8"))
    if only:
        wanted = {item.strip() for item in only.split(",") if item.strip()}
        known = {case["id"] for case in cases}
        unknown = wanted - known
        if unknown:
            raise ValueError(f"Unknown case(s): {', '.join(sorted(unknown))}")
        cases = [case for case in cases if case["id"] in wanted]
    return cases


def validate_publication_set(cases: list[dict[str, Any]]) -> None:
    positives = [case for case in cases if case["type"] == "positive"]
    negatives = [case for case in cases if case["type"] == "negative"]
    if len(positives) != 5 or len(negatives) != 3:
        raise ValueError(
            "The publication test set must contain exactly 5 positive and 3 negative cases."
        )
