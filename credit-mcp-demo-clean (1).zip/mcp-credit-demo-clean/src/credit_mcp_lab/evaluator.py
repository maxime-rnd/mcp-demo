"""Evaluate observed MCP calls against publication cases."""

from __future__ import annotations

from typing import Any


def _matches(expected: Any, actual: Any) -> bool:
    try:
        return abs(float(expected) - float(actual)) < 1e-6
    except (TypeError, ValueError):
        return str(expected).strip().casefold() == str(actual).strip().casefold()


def evaluate(case: dict[str, Any], calls: list[dict[str, Any]], answer: str = "") -> dict[str, bool]:
    names = [f"{call['kind']}:{call['name']}" for call in calls]
    checks: dict[str, bool] = {}

    if case.get("expect"):
        checks["expected_calls"] = all(item in names for item in case["expect"])
    if case.get("forbid"):
        checks["forbidden_calls"] = not any(item in names for item in case["forbid"])

    if case.get("args"):
        valid = True
        for key, wanted in case["args"].items():
            kind, name = key.split(":", 1)
            candidates = [call for call in calls if call["kind"] == kind and call["name"] == name]
            valid = valid and any(
                all(_matches(value, call["args"].get(argument)) for argument, value in wanted.items())
                for call in candidates
            )
        checks["expected_arguments"] = valid

    if case.get("answer_contains"):
        checks["expected_answer"] = all(
            value.casefold() in answer.casefold() for value in case["answer_contains"]
        )

    if case.get("expected_error"):
        checks["expected_error"] = any(not call.get("ok", True) for call in calls)

    return checks


def status(checks: dict[str, bool]) -> str:
    return "PASS" if checks and all(checks.values()) else "FAIL"
