"""CLI for exercising the credit demo through the MCP protocol."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
from typing import Any

from .cases import load_cases, validate_publication_set
from .evaluator import evaluate, status
from .mcp_client import connect_server, result_text

PROJECT_ROOT = Path(__file__).resolve().parents[2]
RESULTS_DIR = PROJECT_ROOT / "lab" / "results"


def _tool_name(case: dict[str, Any]) -> tuple[str, dict[str, Any]] | None:
    expected = case.get("args", {})
    if expected:
        key, args = next(iter(expected.items()))
        kind, name = key.split(":", 1)
        if kind == "tool":
            return name, args
    for item in case.get("expect", []):
        kind, name = item.split(":", 1)
        if kind == "tool":
            return name, {}
    return None


async def run_case(case: dict[str, Any]) -> dict[str, Any]:
    async with connect_server(PROJECT_ROOT) as client:
        available = {tool.name for tool in (await client.list_tools()).tools}
        selected = _tool_name(case)
        if selected is None:
            return {
                "id": case["id"],
                "status": "SKIP",
                "reason": "No direct tool invocation is defined for this case.",
            }

        name, args = selected
        if name not in available:
            checks = {"tool_available": False}
            return {"id": case["id"], "status": "FAIL", "checks": checks}

        try:
            result = await client.call_tool(name, args)
            answer = result_text(result)
            calls = [{"kind": "tool", "name": name, "args": args, "ok": not result.is_error}]
            if case.get("expected_error") and not result.is_error:
                calls[0]["ok"] = True
        except Exception as exc:
            answer = str(exc)
            calls = [{"kind": "tool", "name": name, "args": args, "ok": False, "error": answer}]

        checks = evaluate(case, calls, answer)
        return {
            "id": case["id"],
            "status": status(checks),
            "checks": checks,
            "tool": name,
            "args": args,
            "answer": answer,
        }


async def run_cases(cases: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for case in cases:
        row = await run_case(case)
        rows.append(row)
        marker = row["status"]
        print(f"{marker:>4}  {case['id']}")
        if row.get("answer"):
            print(f"      {row['answer'][:240]}")
    return rows


def save(rows: list[dict[str, Any]], label: str) -> Path:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    path = RESULTS_DIR / f"{label}.json"
    path.write_text(
        json.dumps({"label": label, "cases": rows}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    return path


def list_cases() -> None:
    for case in load_cases():
        print(f"{case['id']:<28} [{case['type']}] {case['prompt']}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    list_parser = sub.add_parser("list", help="List the publication cases")
    list_parser.set_defaults(func=lambda _: list_cases())

    run_parser = sub.add_parser("run", help="Execute the cases through the MCP server")
    run_parser.add_argument("--only", help="Comma-separated case IDs")
    run_parser.add_argument("--label", default="local-mcp", help="Result filename")

    def execute(args: argparse.Namespace) -> None:
        cases = load_cases(args.only)
        if not args.only:
            validate_publication_set(cases)
        rows = asyncio.run(run_cases(cases))
        path = save(rows, args.label)
        passed = sum(row["status"] == "PASS" for row in rows)
        print(f"\nResult: {passed}/{len(rows)} PASS")
        print(f"Saved: {path}")
        if passed != len(rows):
            raise SystemExit(1)

    run_parser.set_defaults(func=execute)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
