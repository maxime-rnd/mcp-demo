"""Application configuration loaded from environment variables."""

from pydantic import AnyHttpUrl, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime settings for the MCP resource server."""

    model_config = SettingsConfigDict(env_file=".env", env_prefix="CREDIT_MCP_", extra="ignore")

    app_name: str = "credit-demo"
    host: str = "127.0.0.1"
    port: int = 8000
    log_level: str = "WARNING"
    allowed_hosts: list[str] = Field(default_factory=lambda: ["127.0.0.1:*", "localhost:*"])

    # Local-only fallback. Never use this mode for a public deployment.
    demo_client_id: str = "CLI-001"

    # Production OAuth resource-server settings.
    oauth_issuer_url: AnyHttpUrl | None = None
    oauth_resource_server_url: AnyHttpUrl | None = None
    oauth_jwks_url: AnyHttpUrl | None = None
    oauth_required_scopes: list[str] = Field(default_factory=lambda: ["credit:read"])
    oauth_audience: str | None = None

    @property
    def oauth_enabled(self) -> bool:
        """Return whether production JWT validation is configured."""
        return all(
            (
                self.oauth_issuer_url is not None,
                self.oauth_resource_server_url is not None,
                self.oauth_jwks_url is not None,
            )
        )
