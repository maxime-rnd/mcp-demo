"""Minimal JSONL audit log with secrets redacted."""

from __future__ import annotations

import functools
import json
import os
import time
from pathlib import Path
from typing import Any, Callable

LOG_PATH = Path(os.getenv("CALL_LOG", Path(__file__).with_name("calls.jsonl")))
SENSITIVE_KEYS = {"authorization", "access_token", "token", "client_secret", "password"}


def _redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: "***REDACTED***" if k.lower() in SENSITIVE_KEYS else _redact(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v) for v in value]
    return value


def log_call(kind: str, name: str, args: dict | None = None, ok: bool = True, error: str | None = None) -> None:
    entry = {"ts": time.time(), "kind": kind, "name": name, "args": _redact(args or {}), "ok": ok}
    if error:
        entry["error"] = error
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")


def logged(kind: str, name: str | None = None):
    def decorator(fn: Callable[..., Any]):
        label = name or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any):
            try:
                result = fn(*args, **kwargs)
            except Exception as exc:
                log_call(kind, label, kwargs, ok=False, error=str(exc))
                raise
            log_call(kind, label, kwargs)
            return result

        return wrapper
    return decorator
