"""OAuth 2.1 resource-server authentication.

The MCP server does not issue OAuth tokens. It validates bearer access tokens
issued by the configured identity provider (IdP).
"""

from __future__ import annotations

import asyncio
import time
from typing import Any

import httpx
import jwt
from jwt.algorithms import RSAAlgorithm
from mcp.server.auth.provider import AccessToken, TokenVerifier


class JwtTokenVerifier(TokenVerifier):
    """Validate RS256 JWT access tokens against an IdP JWKS endpoint."""

    def __init__(
        self,
        *,
        issuer: str,
        audience: str,
        jwks_url: str,
        resource_server_url: str,
        cache_ttl_seconds: int = 300,
    ) -> None:
        self.issuer = issuer.rstrip("/")
        self.audience = audience
        self.jwks_url = jwks_url
        self.resource_server_url = resource_server_url
        self.cache_ttl_seconds = cache_ttl_seconds
        self._jwks: dict[str, Any] | None = None
        self._jwks_expires_at = 0.0
        self._lock = asyncio.Lock()

    async def verify_token(self, token: str) -> AccessToken | None:
        """Return MCP access information when the JWT is valid, otherwise None."""
        try:
            header = jwt.get_unverified_header(token)
            kid = header.get("kid")
            if not kid or header.get("alg") != "RS256":
                return None

            jwks = await self._get_jwks()
            jwk = next((key for key in jwks["keys"] if key.get("kid") == kid), None)
            if jwk is None:
                # One refresh handles key rotation without disabling caching.
                await self._refresh_jwks()
                jwks = self._jwks or {"keys": []}
                jwk = next((key for key in jwks["keys"] if key.get("kid") == kid), None)
            if jwk is None:
                return None

            public_key = RSAAlgorithm.from_jwk(jwk)
            claims = jwt.decode(
                token,
                public_key,
                algorithms=["RS256"],
                audience=self.audience,
                issuer=self.issuer,
                options={"require": ["exp", "iat", "iss", "sub", "aud"]},
            )

            scopes = self._scopes(claims)
            client_id = str(claims.get("azp") or claims.get("client_id") or claims["sub"])
            subject = str(claims["sub"])
            expires_at = int(claims["exp"])
            return AccessToken(
                token=token,
                client_id=client_id,
                scopes=scopes,
                expires_at=expires_at,
                resource=self.resource_server_url,
                subject=subject,
                claims=claims,
            )
        except (jwt.PyJWTError, ValueError, KeyError, TypeError):
            return None

    async def _get_jwks(self) -> dict[str, Any]:
        if self._jwks and time.monotonic() < self._jwks_expires_at:
            return self._jwks
        return await self._refresh_jwks()

    async def _refresh_jwks(self) -> dict[str, Any]:
        async with self._lock:
            if self._jwks and time.monotonic() < self._jwks_expires_at:
                return self._jwks
            async with httpx.AsyncClient(timeout=5.0) as client:
                response = await client.get(self.jwks_url)
                response.raise_for_status()
                data = response.json()
            if not isinstance(data, dict) or not isinstance(data.get("keys"), list):
                raise ValueError("Invalid JWKS document")
            self._jwks = data
            self._jwks_expires_at = time.monotonic() + self.cache_ttl_seconds
            return data

    @staticmethod
    def _scopes(claims: dict[str, Any]) -> list[str]:
        raw = claims.get("scope", "")
        if isinstance(raw, str):
            return [scope for scope in raw.split() if scope]
        if isinstance(raw, list):
            return [str(scope) for scope in raw]
        return []
