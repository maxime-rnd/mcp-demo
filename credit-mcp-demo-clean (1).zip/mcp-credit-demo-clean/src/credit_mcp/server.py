"""MCP server for the credit demo."""

from __future__ import annotations

from typing import Literal

from mcp.server.auth.middleware.auth_context import get_access_token
from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from mcp.server.transport_security import TransportSecuritySettings
from mcp.server.auth.settings import AuthSettings
from mcp.types import ToolAnnotations
from pydantic import AnyHttpUrl

from . import db
from .auth import JwtTokenVerifier
from .config import Settings
from .logging import logged

TypeCredit = Literal["conso", "auto", "travaux", "immo"]
TAUX_ENDETTEMENT_MAX = 0.35


def build_server(settings: Settings | None = None) -> MCPServer:
    """Build the MCP server with production authentication when configured."""
    settings = settings or Settings()
    kwargs: dict = {
        "name": settings.app_name,
        "log_level": settings.log_level,
        "instructions": (
            "Tu aides un client à explorer et préparer une demande de crédit. "
            "Utilise toujours les outils pour obtenir chiffres et statuts : n'invente jamais "
            "un taux, une mensualité ou une décision. Tu peux simuler et préparer un BROUILLON, "
            "mais tu ne peux ni accorder ni soumettre un crédit. Les résultats sont indicatifs "
            "et non contractuels."
        ),
    }

    if settings.oauth_enabled:
        verifier = JwtTokenVerifier(
            issuer=str(settings.oauth_issuer_url),
            audience=settings.oauth_audience or str(settings.oauth_resource_server_url),
            jwks_url=str(settings.oauth_jwks_url),
            resource_server_url=str(settings.oauth_resource_server_url),
        )
        kwargs["token_verifier"] = verifier
        kwargs["auth"] = AuthSettings(
            issuer_url=AnyHttpUrl(str(settings.oauth_issuer_url)),
            resource_server_url=AnyHttpUrl(str(settings.oauth_resource_server_url)),
            required_scopes=settings.oauth_required_scopes,
            validate_token_resource=True,
        )

    mcp = MCPServer(**kwargs)

    def current_client_id() -> str:
        token = get_access_token()
        if token is not None:
            return token.client_id
        if settings.oauth_enabled:
            raise ToolError("Authentication required.")
        return settings.demo_client_id

    def mensualite(montant: float, taux_annuel_pct: float, duree_mois: int) -> float:
        r = taux_annuel_pct / 100 / 12
        if r == 0:
            return montant / duree_mois
        return montant * r / (1 - (1 + r) ** -duree_mois)

    def taeg_pct(montant: float, mensualite_value: float, duree_mois: int, frais: float) -> float:
        net = montant - frais
        lo, hi = 0.0, 1.0
        for _ in range(80):
            mid = (lo + hi) / 2
            pv = mensualite_value * (1 - (1 + mid) ** -duree_mois) / mid if mid > 0 else mensualite_value * duree_mois
            if pv > net:
                lo = mid
            else:
                hi = mid
        return round(((1 + lo) ** 12 - 1) * 100, 2)

    def verifier_bornes(type_credit: str, montant: float, duree_mois: int) -> dict:
        offre = db.get_offre(type_credit)
        if not offre["montant_min"] <= montant <= offre["montant_max"]:
            raise ToolError(f"Montant hors limites pour '{type_credit}' : {offre['montant_min']} à {offre['montant_max']} €.")
        if not offre["duree_min"] <= duree_mois <= offre["duree_max"]:
            raise ToolError(f"Durée hors limites pour '{type_credit}' : {offre['duree_min']} à {offre['duree_max']} mois.")
        return offre

    def simulation(type_credit: str, montant: float, duree_mois: int) -> dict:
        offre = verifier_bornes(type_credit, montant, duree_mois)
        monthly = mensualite(montant, offre["taux_nominal"], duree_mois)
        fees = round(montant * offre["frais_dossier_pct"] / 100, 2)
        return {
            "type_credit": offre["libelle"], "montant": montant, "duree_mois": duree_mois,
            "taux_nominal_pct": offre["taux_nominal"], "mensualite": round(monthly, 2),
            "frais_dossier": fees, "cout_total_credit": round(monthly * duree_mois - montant + fees, 2),
            "taeg_indicatif_pct": taeg_pct(montant, monthly, duree_mois, fees),
            "avertissement": "Simulation indicative, non contractuelle.",
        }

    @mcp.tool(annotations=ToolAnnotations(title="Simuler un crédit", readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False))
    @logged("tool")
    def simuler_credit(montant: float, duree_mois: int, type_credit: TypeCredit) -> dict:
        """Simule un crédit sans créer ni modifier de demande."""
        return simulation(type_credit, montant, duree_mois)

    @mcp.tool(annotations=ToolAnnotations(title="Consulter la capacité d'emprunt", readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False))
    @logged("tool")
    def consulter_capacite_emprunt(type_credit: TypeCredit, duree_mois: int) -> dict:
        """Estime la capacité d'emprunt du client authentifié."""
        client = db.get_client(current_client_id())
        offre = verifier_bornes(type_credit, db.get_offre(type_credit)["montant_min"], duree_mois)
        revenus, charges = client["revenus_mensuels"], client["charges_mensuelles"]
        max_monthly = max(0.0, revenus * TAUX_ENDETTEMENT_MAX - charges)
        r = offre["taux_nominal"] / 100 / 12
        max_amount = max_monthly * (1 - (1 + r) ** -duree_mois) / r if max_monthly else 0.0
        return {
            "revenus_mensuels": revenus, "charges_mensuelles": charges,
            "taux_endettement_actuel_pct": round(charges / revenus * 100, 1),
            "mensualite_max_recommandee": round(max_monthly, 2),
            "montant_max_indicatif": round(min(max_amount, offre["montant_max"]), -2),
            "avertissement": "Estimation indicative, hors étude complète du dossier.",
        }

    @mcp.tool(annotations=ToolAnnotations(title="Préparer un brouillon de demande", readOnlyHint=False, destructiveHint=False, idempotentHint=False, openWorldHint=True))
    @logged("tool")
    def preparer_demande_credit(montant: float, duree_mois: int, type_credit: TypeCredit, objet: str) -> dict:
        """Crée un brouillon uniquement pour le client authentifié; ne soumet jamais le crédit."""
        client_id = current_client_id()
        simulation_result = simulation(type_credit, montant, duree_mois)
        demande = db.create_demande(client_id, type_credit, montant, duree_mois, objet)
        return {
            "demande_id": demande["id"], "statut": demande["statut"], "simulation": simulation_result,
            "lien_finalisation": f"https://banque-demo.example/demandes/{demande['id']}/finaliser",
            "prochaine_etape": "Le client doit ouvrir le lien, compléter ses justificatifs et signer.",
        }

    @mcp.tool(annotations=ToolAnnotations(title="Consulter le statut d'une demande", readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False))
    @logged("tool")
    def statut_demande(demande_id: str) -> dict:
        """Retourne le statut d'une demande appartenant au client authentifié."""
        demande = db.get_demande(demande_id, current_client_id())
        if demande is None:
            raise ToolError(f"Aucune demande '{demande_id}' pour ce client.")
        return demande

    @mcp.tool(annotations=ToolAnnotations(title="Lister mes demandes", readOnlyHint=True, destructiveHint=False, idempotentHint=True, openWorldHint=False))
    @logged("tool")
    def lister_demandes() -> list[dict]:
        """Liste uniquement les demandes du client authentifié."""
        return db.list_demandes(current_client_id())

    @mcp.resource("credit://offres", mime_type="application/json")
    @logged("resource", "credit://offres")
    def grille_offres() -> dict:
        """Grille fictive des offres de crédit."""
        return db.OFFRES

    @mcp.resource("docs://credit/conditions", mime_type="text/plain")
    @logged("resource", "docs://credit/conditions")
    def conditions_generales() -> str:
        """Conditions générales fictives du crédit."""
        return "CONDITIONS (FICTIVES)\n- Taux d'endettement maximum recommandé : 35 %.\n- Délai de rétractation : 17 jours après acceptation de l'offre (valeur fictive de démo).\n- Toute demande est soumise à l'étude du dossier et à l'accord de la banque.\n"

    @mcp.prompt(title="Préparer un dossier de crédit")
    @logged("prompt")
    def preparer_dossier_credit(projet: str, montant: float) -> str:
        return (
            f"Je souhaite financer le projet suivant : {projet}, pour environ {montant:.0f} €.\n"
            "1. Choisis le type de crédit le plus adapté.\n"
            "2. Vérifie ma capacité d'emprunt.\n"
            "3. Simule 2 ou 3 durées.\n"
            "4. Demande-moi confirmation avant de préparer le brouillon de demande."
        )

    return mcp


def main() -> None:
    settings = Settings()
    mcp = build_server(settings)
    if settings.oauth_enabled:
        app = mcp.streamable_http_app(
            transport_security=TransportSecuritySettings(
                allowed_hosts=settings.allowed_hosts,
            )
        )
        import uvicorn
        uvicorn.run(app, host=settings.host, port=settings.port)
    else:
        mcp.run("stdio")


if __name__ == "__main__":
    main()
